package ma.cdgep.paiement.dto;

public interface SyntheseEncheanceEnvoyeeProj {
	
	public Integer getNombreLigneEnvoyee();
	public Integer getNombreLotEnvoye();
	public Double getMontantTotalEnvoye();

}
