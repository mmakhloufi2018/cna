package ma.cdgep.droit.dto;

import java.util.List;

public class _ConjointDto {

	private String idcs;
	private List<ConstatDto> constats;
	
	public String getIdcs() {
		return idcs;
	}
	public void setIdcs(String idcs) {
		this.idcs = idcs;
	}
	public List<ConstatDto> getConstats() {
		return constats;
	}
	public void setConstats(List<ConstatDto> constats) {
		this.constats = constats;
	}
	
	
}
