package ma.cdgep.repository;

public interface RefIdcsDossier {

	public String getReference();

	public String getIdcs();
}
