package ma.cdgep.repository;

public interface InfoControlAjoutMembre {

	public String getReference();

	public String getIdcs();

	public String getPrestation();

	public String getIdcsconjoint();

	public String getGenre();

	public String getCodemenage();

	public String getCin();

	public String getEtatmatrimonial();

	public String getIdcsenfants();

	public String getIdcsconjoints();
}
