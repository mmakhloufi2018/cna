package ma.cdgp.af.utils;

public enum EventEnum {

	STOP, RUN, STOPRETRY, RUNRETRY
}
