package ma.cdgp.af.ControllerThymeleaf;

import ma.cdgp.af.entity.ParametrageCollection;
import ma.cdgp.af.repository.ParametrageRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

public class ParamsControleCOntrollerThym {
}
