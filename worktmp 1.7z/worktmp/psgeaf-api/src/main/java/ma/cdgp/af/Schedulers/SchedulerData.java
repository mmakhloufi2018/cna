package ma.cdgp.af.Schedulers;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SchedulerData {

	private String motif;
	
}
