package ma.cdgp.af.service;

public abstract class  ExecutorSituationPersonne {
	public abstract void executeWork(Long idLot, String type);
}
