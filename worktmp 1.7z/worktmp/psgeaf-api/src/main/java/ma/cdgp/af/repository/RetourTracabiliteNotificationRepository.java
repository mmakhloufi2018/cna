package ma.cdgp.af.repository;

import ma.cdgp.af.entity.RetourTracabiliteNotification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RetourTracabiliteNotificationRepository extends JpaRepository<RetourTracabiliteNotification, Long> {
}
