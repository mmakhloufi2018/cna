//package ma.cdgp.af.ControllerThymeleaf;
//
//
//import lombok.*;
//import org.springframework.stereotype.Service;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Getter
//@Setter
//public class BatchData {
//    private String partenaire;
//    private double demandesPourcentage;
//    private double reponsesPourcentage;
//
//}
