package ma.cdgp.af.repository;

import ma.cdgp.af.entity.TraceEnvoiRetourNotification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TraceEnvoiRetourNotificationRepository extends JpaRepository<TraceEnvoiRetourNotification, Long> {
}
